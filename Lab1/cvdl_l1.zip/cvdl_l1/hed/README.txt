This code has been taken from PyImageSearch blog
https://www.pyimagesearch.com/2019/03/04/holistically-nested-edge-detection-with-opencv-and-deep-learning/
I (Ramon Morros) added hed_detect.py to use the detector as a function.


PyImageSearch is a very good place to learn Computer Vision, either with classical and Deep Learning methods.
It has practical examples with code that solve many CV problems. Also you can purchase a set of very useful
digital books to learn CV with DL.

